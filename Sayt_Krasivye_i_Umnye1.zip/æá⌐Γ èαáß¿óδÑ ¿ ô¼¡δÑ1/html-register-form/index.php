<?php
require "db.php";
$data = $_POST;
$showError = False;

if(isset($data['signup'])){
    $errors = array();
    $showError = True;
    if(trim($data['firstname']) == ''){
        $errors[] = 'укажите имя';
    }
    if(trim($data['email']) == ''){
        $errors[] = 'укажите почту';
    }

    if(trim($data['password']) == ''){
        $errors[] = 'укажите пароль';
    }

    if(R::count('users', 'email = ?', array($data['email'])) >0){
        $errors[] = 'такая почта уже используется';
    }

    if(empty($errors)){
        $user = R::dispanse('users');
        $user->firstname = $data['firstname'];
        $user->email = $data['email'];
        $user->password = password_hash($data['password'], PASSWORD_DEFAULT);
        R::store($user);
    }
}
?>

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Форма регистрации</title>
</head>

<body>
    <main>
        <div class="circle"></div>
        <div class="register-form-container">
            <form action="/signup.php">
                <h1 class="form-title">
                    Регистрация
                </h1>
                <div class="form-fields">
                    <div class="form-field">
                        <input type="text" name="firstname" placeholder="Имя" required pattern="[а-яА-Я]+"
                            title="Имя может содержать только буквы.">
                    </div>
                    <div class="form-field">
                        <input type="email" name="email" placeholder="Почта" required>
                    </div>
                    <div class="form-field">
                        <input type="password" name="password" placeholder="Пароль" required minlength="8" maxlength="128">
                    </div>
                </div>
                <div class="form-buttons">
                    <button class="button" name="signup">Регистрация</button>
                </div>
            </form>
            <p><?php if($showError) { echo showError($errors); }?></p>
        </div>
    </main>
</body>

</html>