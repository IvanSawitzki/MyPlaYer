<?php
require "rb.php";
R::setup('mysql:host=localhost;dbname=MyPlaYer','root' ,'root');
function showError($errors){
    return array_shift($errors);
}
?>